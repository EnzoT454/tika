# Guide de travail — Apache Tika et tâche 2 IFT3913

Ce fichier aide les agents et les membres du binôme à comprendre le dépôt et à reprendre le travail. Il s'applique à l'ensemble du dépôt. Les instructions explicites de l'utilisateur priment sur ce guide.

## 1. Contexte et règles de travail

- Communiquer en français, simplement, en distinguant les faits vérifiés, les hypothèses et le travail restant.
- Travailler **en local, sans push**, conformément à la demande actuelle de l'utilisateur. Ne pas créer de PR, publier de résultats ou modifier le dépôt du cours sans instruction correspondante.
- Le binôme est déjà constitué : **Aqel Hamza — EnzoT454** et **Saidana Mohamed — FakeTMG**. Les liens de remise restent à ajouter ultérieurement. Ne pas refaire l'inscription.
- Ne pas écraser les modifications existantes. Commencer par consulter `git status --short` et la branche courante.
- Ne pas lancer automatiquement toute la tâche quand l'utilisateur demande une seule étape. Achever l'étape autorisée, documenter le résultat et indiquer la suivante.
- Ne pas utiliser de sous-agents sans demande explicite de l'utilisateur.
- Ne pas confondre ce guide avec le rapport évalué : toute la documentation finale de la tâche doit être consolidée dans un unique `readme.md` à la racine.

## 2. Utilité de Tika

Apache Tika est une boîte à outils Java pour identifier le format d'un document et extraire son texte ainsi que ses métadonnées : titre, auteur, type MIME et autres informations disponibles selon le format.

Exemple : une application reçoit des PDF, Word, Excel et courriels. Tika fournit une interface commune pour récupérer leurs contenus. Ces résultats peuvent ensuite alimenter un moteur de recherche, un classement documentaire ou une analyse de texte.

Le traitement général est :

```text
Fichier ou flux de données
    → détection du format
    → sélection de l'analyseur adapté
    → extraction du texte et des métadonnées
    → résultat exploitable par l'application appelante
```

Tika s'appuie sur des bibliothèques spécialisées, notamment PDFBox pour les PDF et Apache POI pour les formats Microsoft Office. Le résultat dépend du contenu et des composants disponibles ; un document scanné peut nécessiter de l'OCR.

Tika peut être utilisé comme bibliothèque Java, application en ligne de commande, serveur HTTP ou service gRPC. `tika-pipes` permet de récupérer des documents, les traiter dans des processus isolés et envoyer les résultats vers différentes destinations.

## 3. Carte du dépôt

| Chemin | Rôle |
|---|---|
| `README.md` | Présentation générale de Tika et instructions de construction. |
| `CONTRIBUTING.md` | Règles de contribution au projet Apache ; ne pas confondre avec la remise universitaire. |
| `pom.xml` | Agrégateur Maven qui déclare les modules. |
| `tika-parent/pom.xml` | Versions, dépendances et configuration partagée des outils. |
| `tika-bom/` | Alignement des versions des composants Tika. |
| `tika-core/` | Interfaces et fonctionnalités communes détaillées ci-dessous. |
| `tika-annotation-processor/` | Processeur d'annotations utilisé lors de la compilation de `tika-core`. |
| `tika-parsers/` | Analyseurs spécialisés par format : PDF, Office, HTML, archives, images, etc. |
| `tika-detectors/`, `tika-encoding-detectors/` | Détecteurs supplémentaires et détection des encodages. |
| `tika-langdetect/` | Identification de la langue du texte. |
| `tika-serialization/` | Sérialisation et configuration de composants Tika. |
| `tika-app/` | Application en ligne de commande. |
| `tika-server/`, `tika-grpc/` | Accès aux fonctionnalités par HTTP ou gRPC. |
| `tika-pipes/` | Traitement de collections de documents, connecteurs d'entrée et de sortie. |
| `tika-example/` | Exemples d'utilisation Java. |
| `tika-integration-tests/`, `tika-e2e-tests/` | Tests d'intégration et de bout en bout ; certains utilisent Docker. |
| `docs/` | Documentation AsciiDoc, navigation et exemples de configuration. |
| `.github/workflows/` | Automatisations GitHub Actions existantes. |
| `tache2.md` | Consignes, plan de réalisation et comptes rendus locaux. |
| `evidence/tache2/` | Preuves des expériences et scripts de reproduction. |

Dans un module Maven :

```text
src/main/java/       code de production
src/main/resources/ ressources du logiciel
src/test/java/       tests
src/test/resources/ ressources des tests
target/              sorties générées, effacées par clean
```

Pour chercher des fichiers ou du texte, utiliser `rg` et `rg --files`. Sur ce disque, exclure les fichiers auxiliaires avec `-g '!**/._*'` placé après les autres filtres si nécessaire.

## 4. Comprendre tika-core

`tika-core` contient les abstractions communes et des utilitaires réutilisés par les autres modules. Les analyseurs spécialisés ne sont pas tous inclus dans ce module.

Dans `tika-core/src/main/java/org/apache/tika/` :

| Élément | Fonction |
|---|---|
| `Tika.java` | Façade simplifiée pour détecter un format ou extraire du texte. |
| `detect/` | Détection du type de contenu. |
| `mime/` | Types MIME, règles et registre des formats. |
| `parser/Parser.java` | Contrat commun d'analyse d'un document. |
| `parser/AutoDetectParser.java` | Détecte le format et délègue à un analyseur approprié. |
| `parser/ParseContext.java` | Contexte et options du traitement. |
| `metadata/` | Stockage et description des métadonnées. |
| `io/` | Lecture des flux, fichiers temporaires et utilitaires de chemins. |
| `sax/` | Gestion du contenu structuré produit pendant l'analyse. |
| `config/` | Configuration et chargement des composants. |

Le contrat `Parser` reçoit un `TikaInputStream`, un gestionnaire de contenu, un objet `Metadata` et un `ParseContext`. Le contenu est transmis au gestionnaire sous forme d'événements SAX/XHTML ; les métadonnées sont renseignées séparément.

Les deux classes retenues pour la tâche 2 sont dans `org.apache.tika.io` :

- **`LookaheadInputStream`** : permet de consulter une fenêtre bornée d'un flux, avec mémorisation/restauration de position. La lecture d'un octet et la lecture dans un tableau sont des méthodes distinctes.
- **`FilenameUtils`** : traite les noms de fichiers, extensions et chemins de documents incorporés ; choisit certaines informations dans les métadonnées et vérifie la résolution d'un chemin dans un répertoire.

Leurs tests directs sont `LookaheadInputStreamTest.java` et `FilenameUtilsTest.java`, dans le même package sous `src/test/java/`.

## 5. Environnement et commandes Maven

Valeurs vérifiées lors des expériences initiales, à recontrôler en cas de changement d'environnement :

| Élément | Valeur |
|---|---|
| Version du projet | `4.0.0-SNAPSHOT` |
| Java local | OpenJDK Homebrew 17.0.18 |
| Maven du wrapper | 3.9.12 |
| JUnit du projet | 6.1.3 |
| JaCoCo | 0.8.15 |
| PIT / connecteur JUnit | 1.25.9 / 1.2.3, exécution validée |
| Branche de travail observée | `tache2-tests` |
| Commit de référence | `a2d75c2c10563b261148e9bafe4046832b33c1a6` |
| Fork configuré | `https://github.com/EnzoT454/tika.git` |

Les versions effectives doivent être vérifiées dans les POM et les journaux. Le commit de référence n'inclut pas les modifications locales non commitées ; les archives contiennent aussi les POM et patches utiles.

Depuis la racine, sur un système de fichiers adapté :

```bash
git status --short
git branch --show-current
java -version
./mvnw -version

# Construction ciblée, tests et installation des dépendances internes
./mvnw -B -pl tika-core -am clean install

# Tests du module lorsque ses dépendances internes sont déjà installées
./mvnw -B -pl tika-core test

# Mutation des deux classes configurées dans le profil
./mvnw -B -pl tika-core -Pmutation org.pitest:pitest-maven:mutationCoverage
```

`-pl` sélectionne un module et `-am` construit ses dépendances internes. `install` inclut les phases de compilation, tests et vérification : il n'est pas nécessaire de relancer `verify` uniquement pour obtenir ces phases. Ne pas lancer PIT sur tout le réacteur avec `-am` sans maîtriser son périmètre.

Ne pas utiliser `-Pfast` ou `-DskipTests` pour produire une preuve de tests réussis. Conserver les contrôles Checkstyle, Spotless et les contrôles applicables du projet. Spotless utilise actuellement `apply` dans la configuration partagée : vérifier le diff après une construction.

## 6. Particularité locale : disque externe et fichiers macOS

Le dépôt se trouve actuellement dans `/Volumes/TOSHIBA_EXT/ift3913/tika`. Des fichiers AppleDouble `._*` apparaissent sur le disque externe. Ils ont provoqué deux échecs réels : Checkstyle a traité un `._*.java` comme du Java, puis Surefire a tenté de charger une fausse classe de test `._*`.

Le `.gitignore` contient `._*` et `_*`, mais cela ne les exclut pas des outils de compilation. Ne pas désactiver globalement les contrôles pour contourner ce problème. Éviter aussi de nommer les nouveaux dossiers de preuves avec un `_` initial.

La procédure validée est une copie temporaire sur le disque interne :

```bash
# Depuis la racine du dépôt original
build_dir=$(python3 evidence/tache2/prepare-local-build.py)
cd "$build_dir"
./mvnw -B -pl tika-core -am clean install
./mvnw -B -pl tika-core -Pmutation org.pitest:pitest-maven:mutationCoverage
```

**Périmètre du script :** il copie les fichiers suivis par Git dans leur état courant, les modules nécessaires et les POM de découverte du réacteur. Depuis l’étape 5, il inclut aussi les fichiers non suivis et non ignorés de `tika-core`, `tika-parent`, `tika-annotation-processor` et `.mvn`, dont les prompts et futurs tests. Vérifier le manifeste avant chaque mesure ; un fichier ignoré ou une preuve dans `evidence/` n’est pas automatiquement une source de test.

Les répertoires temporaires peuvent disparaître. Les rapports utiles doivent être copiés dans le dépôt original, sous `evidence/tache2/`, avant un nettoyage. Ne pas écrire les preuves uniquement dans la copie temporaire ni remplacer les archives A par des résultats ultérieurs.

Les outils peuvent demander un accès au cache `~/.m2` ou au service Ollama local à travers les permissions de l'environnement. Utiliser le mécanisme d'autorisation prévu, sans contourner un refus.

## 7. Objectif de la tâche 2

Le travail consiste à améliorer les tests de **1 à 3 classes** déjà testées mais insuffisamment couvertes, en utilisant ChatUniTest et un modèle ouvert exécuté localement, puis à mesurer la capacité de détection des nouveaux tests avec PIT.

Les modules autorisés sont `tika-core`, `tika-serialization`, `tika-parser-ocr-module`, `tika-parser-pdf-module` et `tika-parser-microsoft-module`. Le travail actuel est limité à `tika-core`.

- **JaCoCo** mesure le code exécuté : lignes, instructions et branches.
- **PIT** modifie temporairement le code compilé pour créer des mutants et observe si les tests détectent la différence.
- **Oracle** : assertion ou règle qui détermine le résultat attendu d'un test.

| Statut PIT | Interprétation |
|---|---|
| `KILLED` | Au moins un test détecte la modification. |
| `SURVIVED` | Les tests exécutés ne détectent pas la modification. |
| `NO_COVERAGE` | Le code muté n'est pas couvert par les tests de l'analyse. |
| Autres statuts | Timeouts, erreurs, mutants non viables, etc. : les présenter séparément. |

Une ligne exécutée n'est pas forcément correctement vérifiée. Un mutant survivant n'est pas automatiquement équivalent : l'équivalence exige une justification sur le domaine d'entrées valide.

Comparer trois états :

| État | Suite de tests |
|---|---|
| A | Tests originaux. |
| B | A + tests issus de ChatUniTest, avec corrections humaines tracées. |
| C | B + compléments manuels visant les mutants restants. |

Garder le même code de production, les mêmes classes cibles et les mêmes réglages PIT entre les états. Calculer `100 × KILLED / total`, préciser le dénominateur et séparer cette métrique des autres indicateurs PIT. Calculer le score global avec les sommes des effectifs.

## 8. Avancement observé au 27 septembre 2026

Ce tableau est un point de reprise, pas une source immuable. Vérifier les fichiers et journaux avant d'annoncer l'état du travail.

| Travail | État vérifié |
|---|---|
| Préparation de l'environnement et tests originaux | Terminé : `BUILD SUCCESS`. |
| Analyse de couverture et choix des classes | Terminé. |
| Installation PIT et mesure A | Terminé, rapports archivés. |
| Configuration Maven ChatUniTest | Validée : plugin 2.1.1, alias local, Mockito limité au profil et prompts adaptés. |
| Modèle local Ollama | Disponible ; requête simple réussie avec la réponse `LOCAL_OK`. |
| Génération effective de nouveaux tests | Terminée et archivée : le pilote `markSupported()` et `FilenameUtils.resolveWithin()` réussissent sans retouche Java ; `calculateExtension()` a un oracle erroné et les trois versions de `skip()` ne compilent pas. |
| Analyse des oracles et registre de corrections | Terminée : `resolveWithin` est écarté comme redondant, `calculateExtension` est retenu après correction de son oracle et les sorties `skip` exigent une réécriture documentée. |
| Mesure B | Terminée : 752 tests, 0 échec ; PIT passe de 88/148 (59,46 %) à 90/148 (60,81 %). Les deux mutants nouvellement tués sont archivés dans `evidence/tache2/B/mutation-delta.json`. |
| Tests manuels et mesure C | Terminés : 9 tests manuels, 761 tests réussis ; PIT atteint 111/148 (75,00 %), avec 27 survivants et 10 mutants non couverts archivés dans `evidence/tache2/C/`. |
| Validation des nouveaux tests dans GitHub Actions | Workflow dédié préparé localement le 3 octobre 2026, YAML et vérification des 12 cas validés sur les rapports C. Exécution GitHub encore à obtenir ; aucun push actuellement autorisé. |
| Rapport final unique et liens de remise | À finaliser. |

Résultats des tests initiaux de `tika-core` : **749 cas comptabilisés, 747 réussis, 2 déjà désactivés, aucun échec ni erreur**. Le processeur d'annotations a également 8 tests réussis.

| Classe | Lignes couvertes | Branches couvertes | Mutants | Tués | Survivants | Non couverts | Score A |
|---|---|---|---:|---:|---:|---:|---:|
| `LookaheadInputStream` | 32/40 — 80 % | 14/16 — 87,50 % | 33 | 19 | 5 | 9 | 57,58 % |
| `FilenameUtils` | 154/175 — 88 % | 86/110 — 78,18 % | 115 | 69 | 30 | 16 | 60,00 % |
| Total mutation | — | — | 148 | 88 | 35 | 25 | 59,46 % |

`TailStream` a été écartée car ses lignes et branches sont déjà couvertes à 100 %. Les deux classes retenues ont des tests préexistants, une couverture incomplète et des mutants `SURVIVED` démontrés.

Lacunes identifiées :

- `LookaheadInputStream.read(byte[], int, int)` n'est pas exécutée dans la référence initiale. `markSupported()` ne l'est pas non plus. Des mutants survivent aussi dans le constructeur et `fill()`.
- `FilenameUtils` laisse notamment des lacunes dans les métadonnées de repli, les chemins réellement présents sur disque, la réduction des chemins longs et certains choix d'extension.
- Les idées de tests du plan sont des hypothèses à vérifier ; ne pas les présenter comme des tests déjà exécutés.

## 9. Reprendre ChatUniTest

Le profil `chatunitest` de `tika-core/pom.xml` prévoit :

- Plugin `io.github.zju-aces-ise:chatunitest-maven-plugin:2.1.1`.
- Modèle installé `qwen2.5-coder:3b`, environ 1,9 Go, quantification `Q4_K_M`.
- Alias Ollama `codeqwen:v1.5-chat` vers `qwen2.5-coder:3b` : même empreinte, aucun autre modèle téléchargé. Cet alias est nécessaire car le plugin possède une liste fermée de noms acceptés.
- URL locale `http://127.0.0.1:11434/v1/chat/completions` ; la valeur `ollama-local` est un paramètre technique, pas une clé secrète.
- Dépendance de test `mockito-junit-jupiter` limitée au profil et prompts dans `tika-core/src/test/chatunitest-prompts/`. Paramètres Maven réels : `enableMultithreading=false`, `enableMerge=false`; `prune` n’est pas pris en charge par cette version.
- Une tentative configurée par méthode (`testNumber=1`), `maxRounds=3`, température 0,2, génération séquentielle, validation d'exécution active.
- Sorties prévues dans `target/chatunitest-tests/` et informations de travail dans `target/chatunitest-info/`.

Le poste dispose de 8 Go de mémoire ; éviter les modèles ou parallélismes excessifs. Le modèle possède une licence Qwen Research archivée : ne pas le décrire comme étant sous Apache 2.0. Le qualifier selon ses métadonnées et sa licence, sans supposer que « local » signifie « libre sans restrictions ».

Avant la génération, vérifier le service avec `ollama list`. Le chargement du plugin et le pilote sont maintenant validés ; consulter `evidence/tache2/generation/pilot-summary.json`. Ne pas se fier au seul `BUILD SUCCESS` de ChatUniTest : les essais 2 et 3 retournaient ce statut alors que tous leurs tests avaient échoué à la compilation.

La génération de l'étape 6 a ciblé des méthodes précises pour conserver des sorties analysables sur une machine de 8 Go. La commande de classe entière suivante n'a pas été exécutée ; elle reste une option distincte, plus coûteuse, depuis la racine de la copie préparée :

```bash
./mvnw -pl tika-core -Pchatunitest chatunitest:class \
  -DselectClass=org.apache.tika.io.LookaheadInputStream
```

Consulter la [documentation du plugin](https://github.com/ZJU-ACES-ISE/chatunitest-maven-plugin) pour la gestion multi-module et les dépendances requises. Le pilote limité est achevé ; préparer maintenant la génération étendue sans écraser ses archives. Ne pas ajouter aveuglément un starter qui modifierait les versions de test ou remplacerait JUnit.

Conserver les sorties brutes avant toute retouche. Distinguer : première réponse du modèle, réparations automatiques, corrections humaines, puis tests manuels supplémentaires. Ne pas produire soi-même des tests en les attribuant à ChatUniTest. Ne pas affaiblir les assertions ou supprimer silencieusement les tests échoués pour obtenir une exécution verte.

Les futures sources acceptées doivent être découvertes par Surefire et intégrées à la copie de construction. Une génération réussie dans le dossier de sortie ne suffit pas à prouver leur exécution par Maven.

## 10. Preuves, rapports et reproduction

| Chemin sous `evidence/tache2/` | Contenu |
|---|---|
| `initial/` | Environnement, commit, sources inventoriées, premiers échecs liés au disque, construction réussie, JaCoCo et Surefire. |
| `selection/` | Inventaire CSV des classes et détail JSON des candidates. |
| `A/` | Configuration PIT, journaux, rapports HTML/XML et inventaire des 148 mutants. |
| `generation/` | Configuration ChatUniTest, modèle et alias Ollama, quatre essais pilotes, prompts/réponses, erreurs et validation Surefire du test réussi. |
| `prepare-local-build.py` | Préparation d'une copie locale ; lire sa limite sur les fichiers non suivis. |
| `analyze-initial-coverage.py` | Extraction des compteurs de couverture archivés. |
| `summarize-mutations.py` | Synthèse des rapports PIT et identifiants des mutants. |

Depuis la racine, recalculer les synthèses sans relancer les tests :

```bash
python3 evidence/tache2/analyze-initial-coverage.py
python3 evidence/tache2/summarize-mutations.py A
```

Ouvrir les rapports sur macOS, depuis n'importe quel dossier :

```bash
open /Volumes/TOSHIBA_EXT/ift3913/tika/evidence/tache2/initial/jacoco/index.html
open /Volumes/TOSHIBA_EXT/ift3913/tika/evidence/tache2/A/pit-reports/index.html
```

Depuis `tika-core/`, le chemin relatif vers le premier rapport est `../evidence/tache2/initial/jacoco/index.html`.

Dans JaCoCo, ouvrir le package `org.apache.tika.io`, puis la classe et la méthode. Vert signifie exécuté, rouge non exécuté, jaune partiellement couvert ; les losanges représentent les branches. Les colonnes `Cov.` portent sur les instructions et les branches ; les compteurs de lignes sont distincts.

Préserver les XML bruts et les paramètres, pas seulement des captures. Le résumé JSON et le CSV sont dérivés des rapports : si les valeurs diffèrent, rechercher la cause plutôt que modifier les chiffres à la main.

## 11. Suite du travail et critères de qualité

Ordre pratique restant :

1. Étendre la génération ChatUniTest aux méthodes utiles des deux classes ; la configuration et le pilote sont validés.
2. Archiver les productions, compter les succès sans retouche et documenter les corrections.
3. Expliquer et critiquer les oracles générés par comparaison avec les tests originaux.
4. Exécuter B et relier chaque mutant nouvellement tué au test, aux données et à l'assertion correspondante.
5. Ajouter les tests manuels utiles, avec nom, intention, motivation des données et justification de l'oracle.
6. Exécuter C et expliquer les mutants encore non détectés.
7. Préparer la CI, puis obtenir une exécution GitHub Actions lorsque la publication sera demandée.
8. Consolider le rapport final et ajouter les liens de remise au moment autorisé.

Le barème alloue 45 % à la documentation des tests générés, des mutants et des tests manuels. Écrire les observations pendant les expériences. Un score élevé sans preuve ni explication ne couvre pas les exigences.

Ne pas modifier le code de production pour améliorer artificiellement le score. Si un bogue est découvert, le distinguer du travail de tests et préserver la comparabilité des états. Ne pas déclarer 100 % de couverture ou une équivalence de mutants sans preuve.

Pour la CI, vérifier les noms et nombres de nouveaux tests exécutés. Les workflows existants visent notamment `main` ; vérifier la branche concernée. Ne pas obtenir une action verte avec des tests ignorés, `continue-on-error`, `-Pfast` ou `-DskipTests`. Les tests générés acceptés peuvent être exécutés en CI sans régénérer les tests ni faire tourner Ollama à chaque push.

## 12. Documentation et remise

Le README actuel présente Apache Tika. `tache2.md` est un document préparatoire et un journal de travail ; ce guide fournit le contexte de reprise. Le rapport de remise doit être autonome dans **un seul `readme.md` à la racine** : environnement, classes, génération, corrections, oracles, A/B/C, mutants, tests manuels, CI et déclaration de l'usage de l'IA.

Éviter deux fichiers `README.md` et `readme.md` distingués uniquement par la casse sur macOS. Préserver l'attribution du projet et effectuer un renommage Git approprié lors de la consolidation. Ne pas disperser les justifications évaluées entre plusieurs documents.

Le petit fichier `tache2/AQEL_SAIDANA/readme.md` du **dépôt du cours** reçoit uniquement les informations du binôme et les liens prévus par son modèle ; il ne remplace pas le rapport technique du fork Tika.

Selon la copie du cours consultée lors de la préparation : nouvelle PR de remise à créer à partir du 9 octobre 2026 à 00 h, échéance le 13 octobre 2026 à 17 h, heure de Montréal. Le workflow examine la date de création de la PR. **Revalider ces dates et règles sur la branche officielle avant toute remise.** Le travail actuel demeure local et aucune publication n'est autorisée par ce guide.

## 13. Sources à consulter en priorité

- [README du projet](README.md).
- [Consignes, plan et comptes rendus de la tâche 2](tache2.md).
- [Documentation d'utilisation](docs/modules/ROOT/pages/using-tika/index.adoc).
- [Documentation développeur](docs/modules/ROOT/pages/developers/index.adoc).
- [Configuration partagée Maven](tika-parent/pom.xml) et [configuration de tika-core](tika-core/pom.xml).
- [Résultats initiaux](evidence/tache2/initial/results.json), [présélection](evidence/tache2/selection/candidates.json) et [mutation A](evidence/tache2/A/mutation-summary.json).

En cas de divergence entre un compte rendu ancien et les fichiers actuels, vérifier les sources, les paramètres, les commits et les journaux. Actualiser ce guide après une étape importante sans transformer une intention en résultat acquis.

## 14. Intégration finale — état au 8 octobre 2026

- Branche active : `tache2-final`, créée depuis Saidana au commit `619ff284`.
  Les branches précédentes et leurs archives restent accessibles via Git.
- Le périmètre final retenu est `EndianUtils`, `MediaType`, `FilenameUtils`.
  Les sections précédentes décrivent l'expérience historique Hamza.
- Travail autorisé une étape à la fois, en local sans push.
- Étape 2 terminée : seul le test manuel Hamza de lien symbolique extérieur
  est ajouté à `FilenameUtilsManualTest` ; les quatre autres cas sont déjà couverts.
- Vérification ciblée : 16 tests manuels réussis, aucun désactivé. La construction
  complète ciblée s'arrête avant Surefire sur 202 erreurs Checkstyle héritées.
  Ne pas confondre la réussite des objectifs directs avec une validation complète.
- Preuves : `tache2-rapports/final-integration/etape-02/`. Aucun nouveau PIT exécuté.
- Étape 3 terminée : 193 méthodes IA inventoriées, 134 conservées sans changement
  d'assertions, 27 corrigées humainement, 32 rejetées et archivées. Les 161 cas
  retenus réussissent sans désactivation. Les XML de toute la suite confirment
  966 cas, 964 réussis et deux désactivations préexistantes.
- Preuves du tri : `tache2-rapports/final-integration/etape-03/` (sources avant/après,
  registre de décisions, journaux et rapports). Validation par objectifs Maven
  directs, sans revendication de construction complète ni nouveau score PIT.
- Étape 4 terminée : ChatUniTest dans le profil `chatunitest`, PIT 1.30.0 et
  connecteur 1.2.3 dans `mutation`, onze opérateurs explicites et le périmètre
  commun `org.apache.tika.*`. Starter retiré ; JUnit 6.1.3 et Mockito 5.23.0.
- Construction complète `-pl tika-core -am clean install` réussie sur disque
  interne : 966 cas core (964 réussis, deux désactivations préexistantes),
  8/8 tests du processeur d’annotations, zéro erreur Checkstyle. Aucun contrôle
  applicable désactivé. Imports et format nettoyés sans changer les assertions.
- Preuves : `tache2-rapports/final-integration/etape-04/`. Aucun nouveau PIT
  ni génération IA exécuté ; les chiffres historiques restent historiques.
- Prochaine étape : refaire les mesures comparables A/B/C avec une même
  configuration et archiver séparément leurs sources et rapports. La CI et
  la consolidation finale restent à effectuer.
