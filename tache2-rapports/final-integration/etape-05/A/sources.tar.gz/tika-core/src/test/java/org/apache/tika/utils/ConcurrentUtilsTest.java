/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.utils;

import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.concurrent.Future;

import org.junit.jupiter.api.Test;

import org.apache.tika.concurrent.SimpleThreadPoolExecutor;
import org.apache.tika.parser.ParseContext;

public class ConcurrentUtilsTest {

    @Test
    public void testExecuteThread() throws Exception {
        ParseContext context = new ParseContext();
        Future result = ConcurrentUtils.execute(context, () ->
        {
            //Do nothing
        });

        assertNull(result.get());
    }

    @Test
    public void testExecuteExecutor() throws Exception {
        ParseContext context = new ParseContext();
        context.set(SimpleThreadPoolExecutor.class, new SimpleThreadPoolExecutor());
        Future result = ConcurrentUtils.execute(context, () ->
        {
            //Do nothing
        });

        assertNull(result.get());
    }

}
