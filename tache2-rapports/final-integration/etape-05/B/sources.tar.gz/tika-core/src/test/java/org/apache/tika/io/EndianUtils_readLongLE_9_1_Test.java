/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.io;

// Test genere par ChatUniTest 2.1.1 (qwen2.5-coder:7b via Ollama), derniere tentative, non compilable tel quel.
// Corrections manuelles (1) :
//   - import errone 'import org.apache.tika.io.BufferUnderrunException;' remplace par 'import org.apache.tika.io.EndianUtils.BufferUnderrunException;'

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.apache.tika.exception.TikaException;
import org.apache.tika.io.EndianUtils.BufferUnderrunException;

@ExtendWith(MockitoExtension.class)
public class EndianUtils_readLongLE_9_1_Test {

    @Mock
    private InputStream inputStream;


    @Test
    public void testReadLongLE() throws IOException, TikaException {
        // Mock the InputStream to return specific values
        when(inputStream.read()).thenReturn(0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0);
        // Call the method under test
        long result = EndianUtils.readLongLE(inputStream);
        // Verify the result
        assertEquals(0xF0DEBC9A78563412L, result);
        // Verify that read() was called exactly 8 times
        verify(inputStream, times(8)).read();
    }

    @Test
    public void testReadLongLE_WithBufferUnderrunException() throws IOException {
        // Mock the InputStream to return -1 (indicating end of stream)
        when(inputStream.read()).thenReturn(0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, -1);
        // Call the method under test and assert that it throws BufferUnderrunException
        assertThrows(BufferUnderrunException.class, () -> EndianUtils.readLongLE(inputStream));
        // Verify that read() was called exactly 8 times
        verify(inputStream, times(8)).read();
    }
}
