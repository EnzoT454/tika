/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.io;

// Test genere par ChatUniTest 2.1.1 (qwen2.5-coder:7b via Ollama), derniere tentative, non compilable tel quel.
// Corrections manuelles (1) :
//   - import errone 'import org.apache.tika.exception.BufferUnderrunException;' remplace par 'import org.apache.tika.io.EndianUtils.BufferUnderrunException;'



import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.apache.tika.exception.TikaException;
import org.apache.tika.io.EndianUtils.BufferUnderrunException;

public class EndianUtils_readIntLE_6_1_Test {

    private EndianUtils endianUtils;

    @BeforeEach
    public void setUp() {
        endianUtils = new EndianUtils();
    }

    @AfterEach
    public void tearDown() {
        endianUtils = null;
    }

    @Test
    @DisplayName("Test readIntLE with valid input")
    public void testReadIntLEValidInput() throws IOException, TikaException {
        byte[] input = new byte[] { 0x12, 0x34, 0x56, 0x78 };
        InputStream inputStream = new ByteArrayInputStream(input);
        int result = endianUtils.readIntLE(inputStream);
        Assertions.assertEquals(0x78563412, result);
    }

    @Test

    @DisplayName("Test readIntLE with negative input")
    public void testReadIntLENegativeInput() throws IOException, TikaException {
        byte[] input = new byte[] { -1, -1, -1, -1 };
        InputStream inputStream = new ByteArrayInputStream(input);
        Assertions.assertEquals(-1, endianUtils.readIntLE(inputStream));
    }

    @Test
    @DisplayName("Test readIntLE with end of stream")
    public void testReadIntLEEndOfStream() throws IOException, TikaException {
        byte[] input = new byte[] {};
        InputStream inputStream = new ByteArrayInputStream(input);
        Assertions.assertThrows(BufferUnderrunException.class, () -> endianUtils.readIntLE(inputStream));
    }
}
