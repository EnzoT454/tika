/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.io;

// Test genere par ChatUniTest 2.1.1 (qwen2.5-coder:7b via Ollama), derniere tentative, non compilable tel quel.
// Corrections manuelles (2) :
//   - import errone 'import org.apache.tika.io.BufferUnderrunException;' remplace par 'import org.apache.tika.io.EndianUtils.BufferUnderrunException;'

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import org.apache.tika.io.EndianUtils.BufferUnderrunException;

public class EndianUtils_readLongBE_10_1_Test {


    @Test
    public void testReadLongBE() throws Exception {
        // Test with valid input
        byte[] input = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 };
        InputStream inputStream = new ByteArrayInputStream(input);
        long result = EndianUtils.readLongBE(inputStream);
        assertEquals(0x0102030405060708L, result);
        // Test with negative input
        input = new byte[] { (byte) 0xFF, (byte) 0xFE, (byte) 0xFD, (byte) 0xFC, (byte) 0xFB, (byte) 0xFA, (byte) 0xF9, (byte) 0xF8 };
        inputStream = new ByteArrayInputStream(input);
        result = EndianUtils.readLongBE(inputStream);
        assertEquals(0xFFFEFDFCFBFAF9F8L, result);
        // Test with buffer underrun
        InputStream shortStream = new ByteArrayInputStream(new byte[] { 0x01, 0x02, 0x03, 0x04 });
        Executable executable = () -> EndianUtils.readLongBE(shortStream);
        assertThrows(BufferUnderrunException.class, executable);
    }
}
