Contrôle Semgrep : technical_error
Référence : 673766a30fb39f6eb3e6f6167c3d29864b3909a6
Version : 2c11ca08776fb5f02ed9accda861ebb2b0384e91
Erreur technique : Expecting property name enclosed in double quotes: line 1 column 2 (char 1)
