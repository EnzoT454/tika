Contrôle Semgrep : passed
Référence : 673766a30fb39f6eb3e6f6167c3d29864b3909a6
Version : 673766a30fb39f6eb3e6f6167c3d29864b3909a6
Alertes : 17 → 17 ; 0 nouvelles, 0 supprimées.
