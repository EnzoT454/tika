Contrôle Semgrep : passed
Référence : 6a07fb319d84a04c465ad012df5530396685f622
Version : 2c11ca08776fb5f02ed9accda861ebb2b0384e91
Alertes : 18 → 17 ; 0 nouvelles, 1 supprimées.
