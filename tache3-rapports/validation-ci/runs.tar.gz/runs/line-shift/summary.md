Contrôle Semgrep : passed
Référence : 673766a30fb39f6eb3e6f6167c3d29864b3909a6
Version : 21bb92fe710af52d166fb1755a65ac931d20242f
Alertes : 17 → 17 ; 0 nouvelles, 0 supprimées.
