Contrôle Semgrep : technical_error
Référence : ?
Version : ?
Erreur technique : fatal: Needed a single revision
