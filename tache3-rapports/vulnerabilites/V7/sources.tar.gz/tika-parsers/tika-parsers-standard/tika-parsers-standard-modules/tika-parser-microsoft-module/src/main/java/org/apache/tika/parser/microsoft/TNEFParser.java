/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.parser.microsoft;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.poi.hmef.Attachment;
import org.apache.poi.hmef.HMEFMessage;
import org.apache.poi.hmef.attribute.MAPIAttribute;
import org.apache.poi.hmef.attribute.MAPIRtfAttribute;
import org.apache.poi.hsmf.datatypes.MAPIProperty;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import org.apache.tika.annotation.TikaComponent;
import org.apache.tika.exception.TikaException;
import org.apache.tika.extractor.EmbeddedDocumentExtractor;
import org.apache.tika.extractor.EmbeddedDocumentUtil;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.EmbeddedContentHandler;
import org.apache.tika.sax.XHTMLContentHandler;

/**
 * A POI-powered Tika Parser for TNEF (Transport Neutral
 * Encoding Format) messages, aka winmail.dat
 */
@TikaComponent
public class TNEFParser implements Parser {
    private static final long serialVersionUID = 4611820730372823452L;

    private static final Set<MediaType> SUPPORTED_TYPES = Collections.unmodifiableSet(
            new HashSet<>(Arrays.asList(MediaType.application("vnd.ms-tnef"),
                    MediaType.application("ms-tnef"), MediaType.application("x-tnef"))));

    public Set<MediaType> getSupportedTypes(ParseContext context) {
        return SUPPORTED_TYPES;
    }

    /**
     * Extracts properties and text from an MS Document input stream
     */
    public void parse(TikaInputStream tis, ContentHandler handler, Metadata metadata,
                      ParseContext context) throws IOException, SAXException, TikaException {

        // We work by recursing, so get the appropriate bits
        EmbeddedDocumentExtractor embeddedExtractor =
                EmbeddedDocumentUtil.getEmbeddedDocumentExtractor(context);

        // Ask POI to process the file for us
        HMEFMessage msg = new HMEFMessage(tis);

        // Set the message subject if known
        String subject = msg.getSubject();
        if (subject != null && subject.length() > 0) {
            metadata.set(TikaCoreProperties.TITLE, subject);
            metadata.set(TikaCoreProperties.SUBJECT, subject);
        }
        XHTMLContentHandler xhtml = new XHTMLContentHandler(handler, metadata, context);
        xhtml.startDocument();
        // Recurse into the message body RTF
        MAPIAttribute attr = msg.getMessageMAPIAttribute(MAPIProperty.RTF_COMPRESSED);
        if (attr != null && attr instanceof MAPIRtfAttribute) {
            MAPIRtfAttribute rtf = (MAPIRtfAttribute) attr;
            handleEmbedded("message.rtf", "application/rtf", false,
                    rtf.getData(), embeddedExtractor, xhtml, context);
        }

        // Recurse into each attachment in turn
        int unknownCount = 0;
        for (Attachment attachment : msg.getAttachments()) {
            String name = attachment.getLongFilename();
            boolean inferredExtension = false;
            if (name == null || name.isEmpty()) {
                name = attachment.getFilename();
            }
            if (name == null || name.isEmpty()) {
                String ext = attachment.getExtension();
                if (ext == null) {
                    ext = "";
                }
                name = EmbeddedDocumentUtil.EmbeddedResourcePrefix.EMBEDDED.getPrefix()
                        + "-" + unknownCount++ + ext;
                inferredExtension = true;
            }
            handleEmbedded(name, null, inferredExtension,
                    attachment.getContents(), embeddedExtractor, xhtml, context);
        }
        xhtml.endDocument();
    }

    private void handleEmbedded(String name, String type, boolean inferredExtension,
                                byte[] contents,
                                EmbeddedDocumentExtractor embeddedExtractor, ContentHandler handler,
                                ParseContext context)
            throws IOException, SAXException, TikaException {
        Metadata metadata = Metadata.newInstance(context);
        if (name != null) {
            metadata.set(TikaCoreProperties.RESOURCE_NAME_KEY, name);
        }
        if (type != null) {
            metadata.set(Metadata.CONTENT_TYPE, type);
        }
        if (inferredExtension) {
            metadata.set(TikaCoreProperties.RESOURCE_NAME_EXTENSION_INFERRED, true);
        }

        if (embeddedExtractor.shouldParseEmbedded(metadata)) {
            try (TikaInputStream tis = TikaInputStream.get(contents)) {
                embeddedExtractor.parseEmbedded(tis,
                        new EmbeddedContentHandler(handler), metadata, context, true);
            }
        }
    }
}
