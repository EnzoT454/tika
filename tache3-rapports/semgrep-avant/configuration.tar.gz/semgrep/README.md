# Scan de référence — tâche 3

Depuis la racine du worktree complet, avec Python 3.11 :

```bash
python3 -m venv /private/tmp/tika-semgrep-venv
/private/tmp/tika-semgrep-venv/bin/python -m pip install -r semgrep/requirements.txt
/private/tmp/tika-semgrep-venv/bin/python semgrep/scan.py --output /private/tmp/semgrep-result.json
```

Semgrep CE est fixé à 1.185.0. `rules.lock.json` identifie la révision et les empreintes des 82 règles Java générales de sécurité, y compris les règles d'audit. Elles sont téléchargées dans un cache temporaire et vérifiées avant utilisation ; aucun compte Semgrep n'est requis. Les métriques et la vérification distante de version sont désactivées.

Les règles upstream sont sous Semgrep Rules License v1.0 : elles ne sont pas redistribuées dans ce dépôt. Leur notice est conservée dans le cache local. Source et conditions : https://github.com/semgrep/semgrep-rules et https://semgrep.dev/legal/rules-license/.

`scope.json` couvre uniquement le Java de production des cinq modules autorisés. Tests, archives, fichiers de construction et AppleDouble sont hors périmètre. Le script ignore les suppressions `nosemgrep` et ne dépend pas de `.gitignore` ; il vérifie que chaque source Java attendue a été analysée, sans erreur ni règle ignorée. L'analyse CE ne garantit pas le suivi de données entre fichiers ou méthodes.

Ce script produit un **scan complet**, pas encore le contrôle différentiel demandé par le cours. Une analyse complète peut terminer avec le code 0 malgré des alertes. Le blocage des nouvelles alertes sera ajouté et validé dans l'étape suivante.

Le rapport initial et ses limites sont conservés dans `tache3-rapports/semgrep-avant/`. Les règles et le périmètre doivent rester identiques lors de la comparaison après injections.
